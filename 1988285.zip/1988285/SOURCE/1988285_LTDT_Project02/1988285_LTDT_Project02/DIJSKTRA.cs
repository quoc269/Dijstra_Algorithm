﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _1988285_LTDT_Project02
{
    class DIJSKTRA
    {
        public  int[] T; int nT; // mảng đánh dấu tập T và biến đếm tương ứng
        public  int[] L; // độ dài từ đỉnh đầu đến các đỉnh khác
        public int[] Prev; // đỉnh liền trước trên đường đi
        
        /*Khởi tạo các thông số cho giải thuật*/
        private void khoiTao(GRAPH g, int source)
        {
            nT = g.soDinh;
           
            for (int i = 0; i < nT; i++ )
            {
                T[i] = 1; //tất cả các đỉnh đều nằm trong T
                L[i] = Int32.MaxValue;  // Su dung lam hang so bieu dien vo cuc;
                Prev[i] = -1;
            }
            L[source] = 0; // khởi tạo cho đỉnh đầu
        }


        public void DijkstraAlg(GRAPH g, int source, int dest)
        {
            //Khởi tạo các thông số cho giải thuật
            khoiTao(g, source);
            // Trong khi đỉnh cuối vẫn trong T
           
            int min, v;
            while (T[dest] == 1 ){
                // Tìm đỉnh có độ dài nhỏ nhất trong T
                min = Int32.MaxValue; 
                v = -1;
                for (int i = 0; i <g.soDinh; i++)
                {
                    if (T[i] != 0 && min > L[i])
                    {
                        min = L[i];
                        v = i;
                    }
                }
                  
                // Nếu không tìm thấy, kết luận không có đường đi, dừng
                if (v == -1)
                    break;
                //Loại v ra khỏi tập T
                T[v] = 0;
                // Duyệt các đỉnh có cạnh nối từ v đến (đồ thị có hướng)
                for (int k = 0; k < g.soDinh; k++)
                {
                    // Chú ý: cách so sánh khác nhau tùy giá trị VOCUC
                    if (g.mtKe[v, k] != 0 && (L[k] > L[v] + g.mtKe[v, k]) && T[k] == 1)
                    {
                        L[k] = g.mtKe[v, k] + L[v];
                        Prev[k] = v;
                    }
                }
            }
          
        }
           
        

        public void RunModule(string filePath)
        {
            GRAPH g = new GRAPH();
          
            g = g.docDoThi(filePath);
            //in do thi khao sat
            g.inDoThi(g);
            if(g.chiPhiAm(g) == true)
            {
                Console.WriteLine("Khong tim duoc duong di ngan nhat do do thi co canh am");
            }
            else
            { // Khoi tao thuat toan
                T = new int[g.soDinh];
                L = new int[g.soDinh];
                Prev = new int[g.soDinh];
                Console.WriteLine("Hay nhap vao dinh bat dau va dinh ket thuc (chi muc tinh tu 0 den " + (g.soDinh - 1).ToString() + "): ");
                Console.Write("Dinh bat dau: ");
                int source = Int32.Parse(Console.ReadLine());
                Console.Write("Dinh ket thuc: ");
                int target = Int32.Parse(Console.ReadLine());



                // chay thuat toan
                DijkstraAlg(g, source, target);

                if (T[target] == 1)
                    Console.WriteLine("Khong co duong di");
                else
                {
                    // in duong di kieu nguoc
                    Console.Write("Duong di ngan nhat: ");
                    int dinhdangxet = target;
                    while (dinhdangxet != source)
                    {
                        Console.Write(dinhdangxet.ToString() + " <- ");
                        dinhdangxet = Prev[dinhdangxet];
                    }
                    Console.WriteLine(dinhdangxet.ToString());
                    Console.WriteLine("Chi phi duong di ngan nhat: " + L[target].ToString());
                }
            }
            
        }
    }
}

