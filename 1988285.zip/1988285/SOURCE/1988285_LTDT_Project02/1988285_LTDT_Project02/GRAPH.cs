﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace _1988285_LTDT_Project02
{
    class GRAPH
    {
        public int soDinh;
        public int[,] mtKe;
        

        //doc do thi tu file

        public GRAPH docDoThi(string filePath)
        {
            GRAPH dt = new GRAPH();
            StreamReader doc = new StreamReader(filePath);
            dt.soDinh = int.Parse(doc.ReadLine());
            dt.mtKe = new int[dt.soDinh, dt.soDinh];

            int i = 0;
            while (!doc.EndOfStream)
            {
                string dong = doc.ReadLine();
                string[] mang = dong.Split(' ');

                for (int j = 0; j < dt.soDinh; j++)
                {
                    dt.mtKe[i, j] = int.Parse(mang[j]);

                }
                i++;
            }
            
            doc.Close();
            return dt;
        }

        //in do thi ra console
        public void inDoThi(GRAPH dt)
        {
            Console.WriteLine(dt.soDinh);
            for (int i = 0; i < dt.soDinh; i++)
            {
                for (int j = 0; j < dt.soDinh; j++)
                {
                    Console.Write(dt.mtKe[i, j] + " ");
                }
                Console.WriteLine(" ");
            }
        }

        public bool chiPhiAm(GRAPH dt)
        {
            bool  chiPhiAm = false;
            for (int i = 0; i < dt.soDinh && chiPhiAm == false; i++)
            {
                for (int j = 0; j < dt.soDinh; j++)
                {
                 if(dt.mtKe[i,j] < 0)
                    {
                        chiPhiAm = true;
                        break;

                    }
                }
                
            }
            return chiPhiAm;
        }
    }
}
