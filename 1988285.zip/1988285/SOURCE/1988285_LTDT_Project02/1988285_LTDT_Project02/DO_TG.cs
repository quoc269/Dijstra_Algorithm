﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace _1988285_LTDT_Project02
{
   public  class DO_TG
    {
      

       public static void DoThoiGianDIJSKTRA(string filePath1a)
        {
            Stopwatch st = new Stopwatch();
            st.Reset(); // reset thời gian
            st.Start(); // bắt đầu tính thời gian

            // bắt đầu làm việc gì đó, ví dụ gọi hàm cần đo thời gian.
            DIJSKTRA dij = new DIJSKTRA();
             //cau 1.a do thi khong chua canh chi phi am
            dij.RunModule(filePath1a);
            st.Stop(); // kết thúc đo thời gian
            long timeelapsed = st.ElapsedMilliseconds; // thời gian thực hiện
            Console.WriteLine($"thoi gian thuc hien la: {timeelapsed}");
        }

        public static void DoThoiGianBELLMAN_FORD(string filePath1a)
        {
            Stopwatch st = new Stopwatch();
            st.Reset(); // reset thời gian
            st.Start(); // bắt đầu tính thời gian

            // bắt đầu làm việc gì đó, ví dụ gọi hàm cần đo thời gian.
           BELLMAN_FORD dij = new BELLMAN_FORD();
           //cau 1.a do thi khong chua canh chi phi am
            dij.RunModule(filePath1a);
            st.Stop(); // kết thúc đo thời gian
            long timeelapsed = st.ElapsedMilliseconds; // thời gian thực hiện
            Console.WriteLine($"thoi gian thuc hien la: {timeelapsed}");
        }
    }
}
