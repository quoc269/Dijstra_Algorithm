﻿using System;


namespace _1988285_LTDT_Project02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("MSSV:1988285");
            Console.WriteLine("HO TEN: NGUYEN VIET QUOC");
            
                        
                    Console.WriteLine("CAU 1.a/ Tim duong di co chi phi khong am: ");
                    string filePath1a = "e:\\input.txt"; //cau 1.a do thi khong chua canh chi phi am
                    Console.WriteLine("Tim duong di bang Giai thuat DIJSKTRA: ");
                    DIJSKTRA dij = new DIJSKTRA();
                    dij.RunModule(filePath1a);
                    Console.WriteLine("=======================================================================================");
                    Console.WriteLine("Tim duong di bang Giai thuat BELMAN-FORD: ");
                    BELLMAN_FORD bf = new BELLMAN_FORD();
                    bf.RunModule(filePath1a);
                    Console.WriteLine("=======================================================================================");
                    Console.WriteLine("CAU 1.b/ Tim duong di co chi phi am: ");
                    string filePath1b = "e:\\input-cpa.txt"; //cau 1.a do thi khong chua canh chi phi am
                    Console.WriteLine("=======================================================================================");
                    Console.WriteLine("Tim duong di bang Giai thuat DIJSKTRA: ");
                    dij.RunModule(filePath1b);
                    Console.WriteLine("=======================================================================================");
                    Console.WriteLine("Tim duong di bang Giai thuat BELMAN-FORD: ");
                    bf.RunModule(filePath1b);
                    Console.WriteLine("=======================================================================================");
                    Console.WriteLine("NHAN XET: ");
                    Console.WriteLine("1/ Duong di cau 1.a: voi DIJSKTRA tim thay 1 duong di duy nhat tu nguon toi dich," +
                        " voi BELMAN-FORD: tim thay n duong di ngan nhat(n = so dinh) tu nguon ");

                    Console.WriteLine("2/ Duong di cau 1.b: voi DIJSKTRA  khong tim thay duong di  tu nguon toi dich," +
                        " voi BELMAN-FORD: tim thay n duong di ngan nhat(n = so dinh) tu nguon neu khong co mach am ");
           
                    Console.WriteLine("CAU 2: ");
                    Console.WriteLine("NHAN XET: ");
                    Console.WriteLine("1/ Co su khac biet ve toc do thuc hien cua 2 thuat toan. ");
                    Console.WriteLine("2/ Toc do thuc hien cua DIJSKTRA nhanh hon so voi BELMAN-FORD  ");
                    Console.WriteLine("=======================================================================================");
                    //Do thoi gian thuc hien thuat toan
                    string soDinh7 = "e:\\input-7-dinh.txt";
                    string soDinh10 = "e:\\input-10-dinh.txt";
                    string soDinh40 = "e:\\input-40-dinh.txt";

                    //CAU 2.a / duong di ngan nhat qua 7 dinh
                    Console.WriteLine("Duong di ngan nhat qua 7 dinh");
                    DO_TG.DoThoiGianBELLMAN_FORD(soDinh7);
                    DO_TG.DoThoiGianDIJSKTRA(soDinh7);
                    Console.WriteLine("=======================================================================================");
                    //CAU 2.b/ duong di ngan nhat qua 10 dinh
                    Console.WriteLine("Duong di ngan nhat qua 10 dinh");
                    DO_TG.DoThoiGianBELLMAN_FORD(soDinh10);
                    DO_TG.DoThoiGianDIJSKTRA(soDinh10);
                    Console.WriteLine("=======================================================================================");
                    // CAU 2.b / duong di ngan nhat qua 10 dinh
                    Console.WriteLine("Duong di ngan nhat qua 40 dinh");
                    DO_TG.DoThoiGianBELLMAN_FORD(soDinh40);
                    DO_TG.DoThoiGianDIJSKTRA(soDinh40);

            
            Console.WriteLine("=======================================================================================");
            Console.WriteLine("CAU 3 ");
            Console.WriteLine("Tim dac diem thuat toan BELLMAN-FORD, DIJSKTRA: ");
            Console.WriteLine("1/ Bellman-Ford co the tim duoc duong di voi chi phi am vi: qua moi buoc lap deu cap nhat lai chi phi cua tat ca cac dinh");
            Console.WriteLine("2/ Dijsktra khong the tim duoc duong di voi chi phi am vi: Dijsktra dua tren phuong phap Greedy(greedy method):" +
                "them mot dinh moi vao se lam tang khoang cach. Neu mot dinh co chi phi am duoc them vao se lam xao tron cac trat tu cac dinh da duoc them truoc do." +
                " Do cac dinh da them da bi danh dau va xoa khoi tap hop nen dieu nay khong the thuc hien ");



        }
    }
}
